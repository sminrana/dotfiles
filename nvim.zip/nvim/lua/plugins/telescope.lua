return {
  "nvim-telescope/telescope.nvim",
  keys = {
    {
      "<leader>fv",
      function()
        require("telescope.builtin").live_grep({
          cwd = vim.fn.stdpath("config"),
          prompt_title = "Neovim",
        })
      end,
      desc = "Live Grep in Neovim config files",
    },
    {
      "<leader>fa",
      function()
        require("telescope.builtin").live_grep({
          cwd = "~/app/",
          prompt_title = "App",
        })
      end,
      desc = "Live Grep in App Files",
    },
    {
      "<leader>fw",
      function()
        require("telescope.builtin").live_grep({
          cwd = "~/web/",
          prompt_title = "Web",
        })
      end,
      desc = "Live Grep in Web Files",
    },
    {
      "<leader>fx",
      function()
        require("telescope.builtin").live_grep({
          cwd = "~/Desktop/obs-v1/",
          prompt_title = "Notes",
        })
      end,
      desc = "Live Grep in Notes Files",
    },
    {
      "<leader>fo",
      function()
        require("telescope.builtin").live_grep({
          grep_open_files = true,
          prompt_title = "Open Files",
        })
      end,
      desc = "Live Grep in in Open Files",
    },
    {
      "<leader>/",
      require("telescope.builtin").current_buffer_fuzzy_find,
      desc = "Current Buffer Fuzzy",
    },
    {
      "<leader>.",
      require("telescope.builtin").live_grep,
      desc = "Live Grep (Root dir)",
    },
  },
}
