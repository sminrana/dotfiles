return {
  "mbbill/undotree",
  config = function() end,
}

