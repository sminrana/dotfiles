return {
  "nvim-lualine/lualine.nvim",
}
