return {
  "stevearc/conform.nvim",
  lazy = true,
  event = { "BufReadPre", "BufNewFile" },
  opts = {
    formatters_by_ft = {
      php = { "php-cs-fixer" },
      lua = { "stylua" },
      -- Conform will run multiple formatters sequentially
      python = { "isort", "black" },
      -- You can customize some of the format options for the filetype (:help conform.format)
      rust = { "rustfmt", lsp_format = "fallback" },
      -- Conform will run the first available formatter
      swift = { "swiftformat_ext" },
      javascript = { "prettier" },
      typescript = { "prettier" },
      javascriptreact = { "prettier" },
      typescriptreact = { "prettier" },
      svelte = { "prettier" },
      css = { "prettier" },
      html = { "prettier", "htmlbeautifier" },
      json = { "prettier" },
      yaml = { "prettier" },
      markdown = { "prettier" },
      graphql = { "prettier" },
      liquid = { "prettier" },
      -- blade = { "php-cs-fixer" },
    },
    notify_on_error = true,
    -- format_on_save = {
    --   lsp_fallback = true,
    --   async = false,
    --   timeout_ms = 1000,
    -- },
    log_level = vim.log.levels.ERROR,
    formatters = {
      ["php-cs-fixer"] = {
        command = "php-cs-fixer",
        args = {
          "fix",
          "--rules=@PSR12", -- Formatting preset. Other presets are available, see the php-cs-fixer docs.
          "$FILENAME",
        },
        stdin = false,
      },
      swiftformat_ext = {
        command = "swiftformat",
        args = { "--config", "~/.config/nvim/.swiftformat", "--stdinpath", "$FILENAME" },
        range_args = function(ctx)
          return {
            "--config",
            "~/.config/nvim/.swiftformat",
            "--linerange",
            ctx.range.start[1] .. "," .. ctx.range["end"][1],
          }
        end,
        stdin = true,
        condition = function(ctx)
          return vim.fs.basename(ctx.filename) ~= "README.md"
        end,
      },
    },
  },
}
