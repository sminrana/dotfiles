# Neovim + LazyVim

## Welcome to my Neovim configuration files.

### My Neovim is ready for

1. Laravel
2. Xcode for iOS

### Mac Shortcut
Get Mac shortcut to open any file or folder from Finder in Neovim + kitty
https://www.icloud.com/shortcuts/5295a8e5e1154d1195c027d7448bbaac.


#### Use with other terminal
You can use it with any terminal just change the terminal bundle identifier in the shortcut.

Bundle Identifier for kitty: net.kovidgoyal.kitty

open -n -b "net.kovidgoyal.kitty" --args "nvim" "$1"
